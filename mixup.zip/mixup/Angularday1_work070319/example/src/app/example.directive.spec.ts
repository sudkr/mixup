import { ExampleDirective } from './example.directive';

describe('ExampleDirective', () => {
  it('should create an instance', () => {
    const directive = new ExampleDirective();
    expect(directive).toBeTruthy();
  });
});
