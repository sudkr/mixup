import { Directive, ElementRef, Renderer, HostListener, HostBinding, Input } from '@angular/core';


@Directive({
    selector: '[appExample]'
})
export class ExampleDirective {
    @HostListener('mouseenter') mouseover() {
        // this.backgroundColor='green';
        this.backgroundColor = this.highlightColor;
    }
    @HostListener('mouseleave') mouseleave() {
        //this.backgroundColor='white';
        this.backgroundColor = this.defaultColor;
    }
    @HostBinding('style.backgroundColor') get setColor() {
        return this.backgroundColor
    }
    @Input() defaultColor = 'white';
    @Input() highlightColor = 'green';
    private backgroundColor: string;
    // private backgroundColor=this.defaultColor
    //private backgroundColor='white'
    constructor(private elementRef: ElementRef, private renderer: Renderer) {
        //this.elementRef.nativeElement.style.backgroundColor='green';
        this.renderer.setElementStyle(this.elementRef.nativeElement, 'backgroundColor', 'green')
    }

}
