import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'example';
  switch=true;
  friendsList=["Sud","Vikas","Hero","Rahul"];
  value=300;
  onSwitch(){
    this.switch=!this.switch;
  }
}
