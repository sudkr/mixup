import { Component, OnInit } from '@angular/core';
import { Movie } from 'src/app/model/Movie';
import { Router } from '@angular/router';
import { MoviesService } from 'src/app/Services/movies.service';


@Component({
  selector: 'app-searchmovie',
  templateUrl: './searchmovie.component.html',
  styleUrls: ['./searchmovie.component.css']
})
export class SearchmovieComponent implements OnInit {
  movies: Movie[];
  ddgenre: string;
  moviename: string[] = [];
  constructor(private router: Router, private movieservice: MoviesService) { }
  ngOnInit() {
    this.movieservice.getmovies().subscribe(data => { this.movies = data })
  }
  showMovie(frm): void {
    console.log(frm.value);
    for (let search of this.movies) {
      //console.log(search.name);
      if (frm.value.ddgenre == search.ddgenre) {
        //console.log(search.name);
        this.moviename.push(search.name);
      }
    }
  }
}
