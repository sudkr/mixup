import { Component, OnInit } from '@angular/core';
import { Movie } from 'src/app/model/Movie';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { MoviesService } from 'src/app/Services/movies.service';

@Component({
  selector: 'app-addmovie',
  templateUrl: './addmovie.component.html',
  styleUrls: ['./addmovie.component.css']
})
export class AddmovieComponent implements OnInit {

  movies: Movie[];
  addForm: FormGroup;
  submitted:boolean=false;

  constructor(private formbuilder:FormBuilder,
    private router:Router, private movieservice:MoviesService) { }


   
  ngOnInit() {
    this.addForm = new FormGroup(
      {
        name : new FormControl('',
         [Validators.required, Validators.pattern(/^[a-zA-Z0-9_-]*$/)]),
        rating : new FormControl('', [Validators.required,
         Validators.pattern('[1-5]*')]),
         ddgenre : new FormControl('', [Validators.required])
        }
    )
    this.movieservice.getmovies().subscribe(data=>{
      this.movies = data;
    });

 }
  onSubmit()
  {
    this.submitted = true;
    if(this.addForm.invalid)
    {
      return;
    }
    this.movieservice.createMovie(this.addForm.value)
    .subscribe(data =>{ 
      alert('record added..!!');
    });
    this.router.navigate(['/addmovie']);
  }
  //delete


//adding User
addMovie():void
 {
  this.router.navigate(['/addmovie']);
 }
 
}

