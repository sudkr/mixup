import { Component, OnInit } from '@angular/core';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Employee } from '../model/emp';
import { empty } from 'rxjs';


@Component({
  selector: 'app-assign2',
  templateUrl: './assign2.component.html',
  styleUrls: ['./assign2.component.css']
})
export class Assign2Component implements OnInit {
  
  addForm:FormGroup;
  submitted:boolean=false;
  editForm:FormGroup;
  submittededit:boolean=false;

  constructor(private formbuilder:FormBuilder,private router:Router,) { }

   ngOnInit() {
     console.log("awesom0")
    this.addForm=this.formbuilder.group({
     
      id:[''],
      name:['',Validators.required],
      salary:['',Validators.required],
      department:['',Validators.required]     
  });
  this.editForm=this.formbuilder.group({
     
    id:[''],
    name:['',Validators.required],
    salary:['',Validators.required],
    department:['',Validators.required]  

});
  console.log("awesome1")
  }

  emp:any[]= [
    {
      id:1001, name:"Rahul", salary:9000, department:"java"
    },
    {
      id:1002, name:"Sachin", salary:19000, department:"ora apps"
    },
    {
      id:1003, name:"Vikash", salary:29000, department:"bi"
    }
  ];
  addEmployee(){
    alert(this.addForm.value);
    this.emp.push(this.addForm.value);

  }
 

  onSubmit(){
 
    this.submitted=true;
    if(this.addForm.invalid){
      return ;
    }
    console.log('DATA INSERTED');
  }
 

  editEmployee(id: number, name: string, salary: string, department: string)
  {

  }


  onSubmitedit(){
 
    this.submittededit=true;
    if(this.editForm.invalid){
      return ;
    }
    let id=this.editForm.value.id
    for(let i=0;i<this.emp.length;i++){
      if(this.emp[i].id==id){
        this.emp[i]=this.editForm.value;
      }
    }

   
  }
  delete(e:Employee){

   this.emp=this.emp.filter(u=>u!=e)
  }
  
}













