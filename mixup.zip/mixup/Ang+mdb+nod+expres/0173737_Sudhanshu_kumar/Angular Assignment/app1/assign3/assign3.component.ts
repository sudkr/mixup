import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assign3',
  templateUrl: './assign3.component.html',
  styleUrls: ['./assign3.component.css']
})
export class Assign3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  AddProduct(form)
  {
    console.log(form.value);
    console.log('Product Id: '+form.value.id);
    console.log('Product Name: '+form.value.name);
    console.log('Product Cost: '+form.value.cost);
    console.log('Product Online: '+form.value.productonline);
    console.log('Product Category: '+form.value.ddpcategory);
    console.log('Available in store: '+form.value.availableinstore);
   
  }
}
