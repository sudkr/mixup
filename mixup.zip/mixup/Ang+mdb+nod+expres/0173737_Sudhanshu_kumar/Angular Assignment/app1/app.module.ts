import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Assgin1Component } from './assgin1/assgin1.component';
import { Assign2Component } from './assign2/assign2.component';
import { HomeComponent } from './home/home.component';
import { Assign3Component } from './assign3/assign3.component';




@NgModule({
  declarations: [
    AppComponent,
    Assgin1Component,
    Assign2Component,
    HomeComponent,
    Assign3Component
    
    
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
