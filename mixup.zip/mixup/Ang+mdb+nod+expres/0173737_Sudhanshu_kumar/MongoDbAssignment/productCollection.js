use cgProductDb
db.createCollection("ProductCollection",{capped:false,autoIndexId:false,size:5040320,max:50})



db.ProductCollection.insert([
    { _id:1,
    item:"Laptop",
    prodCat :"Electronics",
    price:30000.0,
    quantity: 2,
    orderInfo:{_id:"O001",orderdate: ISODate("2014-01-01")},
    address:{street:"66,Airoli",city:"Mumbai",state:"MS",zipcode:700987},
    coords: [ -73.856077, 40.848447 ],
    email:"capgemini@capgemini.com",
    mobiles:[8888108810]
        
    }
    ])
db.ProductCollection.insert([
    {
        _id:2,
        item:"Mobile",
        prodCat :"Electronics",
        price:15000.0,quantity: 10,
        orderInfo:{"_id":"O002",orderdate : ISODate("2010-03-12")},
        address:{street:"FC Road",city:"Pune",state:"MS",zipcode:40081},
        coords: [ -23.80007, 30.1123456 ],
        email:"icres@ibm.com",
        mobiles:[9856342189]
          
    }
    ])
    db.ProductCollection.insert([
    {
        _id:3,
item:"Shirt",
prodCat :"Clothing",
price:1400.0,
quantity: 20,
orderInfo:{"_id":"O003",
orderdate : ISODate("2014-05-18")},
address:{street:"MG Road",city:"Bangalore",state:"Kar",zipcode:560076},
coords: [ -25.80567, 28.393939 ],
email:"capg@capg.com",
mobiles:[7019485329]
    
    }
    ])
    db.ProductCollection.insert([
    {
        _id:4,
item:"Flowers",
prodCat :"Shopping",
price:245.0,
quantity: 100,
orderInfo:{"_id":"O004",orderdate : ISODate("2015-06-19")},
address:{street:"Laxmi Road",city:"Hyderabad",state:"AP",zipcode:560077},
coords: [ -52.80000, 26.1234566 ],
email:"imm@imm.com",
mobiles:[8105017552]
    
    }
    ])
db.ProductCollection.insert([
    {
        _id:5,
item:"TV",
prodCat :"Electronics",
price:24000.0,
quantity: 10,
orderInfo:{"_id":"O003",
orderdate : ISODate("2012-06-17")},
address:{street:"GT Road",city:"Sahibabad",state:"UP",zipcode:567777},
coords: [ -11.80007, 13.1123456 ],
email:"techm@techm.com",
mobiles:[7865452222]
     
    }
    ])
db.ProductCollection.insert([
    { 
        _id:6,
item:"Bangles",
prodCat :"Jewellery",
price:4000.0,
quantity: 1,
orderInfo:{"_id":"O004",orderdate : ISODate("2010-05-16")},
address:{street:"Salt Lake",city:"Kolkata",state:"West Bengol",zipcode:222224},
coords: [ -67.850007, 9.456666 ],
email:"vaishali@gmail.com",
mobiles:[8888108850,9402312123]
    
    }
])
db.ProductCollection.insert([{
    _id: 7,
    item: "Necklace",
    prodCat: "Jewellery",
    price: 90000.0,
    quantity: 2,
    orderInfo: {
        _id: "O007",
        orderdate: ISODate("2014-01-01"),
        address: {
            street: "78,Aundh",
            city: "Pune",
            state: "MS",
            zipcode: 700987,
            coords: [-73.856077, 40.848447]
        },
        email: "capgemini@capgemini.com",
        mobiles:9008151521
    }
}])

db.ProductCollection.insert([{
    _id: 8,
    item: "Pen",
    prodCat: "Stationary",
    price: 20.0,
    quantity: 30,
    orderInfo: {
        _id: "O008",
        orderdate: ISODate("2014-01-01"),
        address: {
            street: "67,MGRoad",
            city: "Mumbai",
            state: "MS",
            zipcode: 700987,
            coords: [-73.856077, 40.848447]
        },
        email: "capgemini@capgemini.com",
        mobiles: 8888108810
    }
}])
db.ProductCollection.remove({})
//1.4
db.ProductCollection.find()
//1.5
db.ProductCollection.find({},{"coords":0,"email":0}).pretty()
//1.6
db.ProductCollection.update({"_id":3},{$set: {"orderstatus":"pending"}})
//1.7
db.ProductCollection.update({"item":"Laptop"},{$set: {"price":5000}})
//1.9
db.ProductCollection.update({"_id":2},{$set: {"mobiles":9082726252}})
//or
// 1.9
 db.ProductCollection.update({_id:2}, {$set:{orderInfo:{mobiles:[9856342189,9632455895]}}})

// 1.10
db.ProductCollection.update({item:"CD"}, {$set:{price: 40.0,prodCat:"Electronics"}})



// 1.12
db.ProductCollection.remove({_id:4})

// 1.13
db.ProductCollection.remove({item:/^c/})

// 1.14
db.ProductCollection.find({$or: [{prodCat: "Electronics"},{prodCat:"TV"}]})

// 1.15
db.ProductCollection.find({price:{$gt: 40000}})

// 1.16
db.ProductCollection.find({price:{$gt: 40000}},{_id:0,item:1,prodCat:1,price:1})

// 1.17
db.ProductCollection.find({price:{$gt: 40000}},{_id:0,item:1,prodCat:1,price:1}).limit(3)

// 1.18
db.ProductCollection.aggregate([{$match: {"orderInfo.address.state": "MS"}}])

// 1.19
db.ProductCollection.aggregate([{$sort: {price:-1}}])

// 1.20
db.ProductCollection.aggregate([{$sort: {prodCat:1}}])

// 1.21
db.ProductCollection.find().limit(3)

//1.22
db.ProductCollection.find().forEach(function(p){
    var details= "Product Name="+p.item +"Product Category=" +p.prodCat+ "Price="+p.price+ "Order date= " +p.orderInfo.orderdate 
    + " Order State="+ p.orderstate;
    print(details);
    
})

//1.23
db.ProductCollection.find({$or: [{"address.state":"MS"},{"address.state":"UP"}]})
//1.24
db.ProductCollection.find({$and: [{"price":{$gt: 40000}},{"address.state":"MS"}]})
//1.25
db.ProductCollection.find({"address.city":"Pune"})

//1.26
db.ProductCollection.find().sort({"prodCat":1})


//2.1
db.ProductCollection.find({"prodCat":"Electronics"})

//2.2
db.ProductCollection.aggregate( [ { $group : { _id : "$prodCat" } } ] ).count()
//2.3
db.ProductCollection.find({"prodCat":"Jewellery"}).count()

//2.4
db.ProductCollection.aggregate([
    {$group:  {
    _id : "$prodCat" ,
    averageprice: {$avg: "$price"},
    averagequantity: {$avg: "$quantity"}
    }   
    }])

//2.5
db.ProductCollection.find({"quantity":{$gt: 30}},{"item":1, "prodCat":1, "price":1}).limit(3)

//2.6
db.ProductCollection.find().sort({"quantity":1})
//2.7

db.ProductCollection.aggregate( [ { $group : { _id : "$prodCat",
sumprice:{$sum: "$price"}
    
} } ] )

//2.8
db.ProductCollection.aggregate([
    {
     $group: { _id: "$item",
     maximum: {$max: "$price"}
         
     }
}])
    
//2.9
db.ProductCollection.find({"oderInfo.orderdate": {$year: "$2010"}})
  
//2.10
db.ProductCollection.aggregate([
    {
        $group: { _id: "$prodCat",
            ProductName: {$push: "$item"},
            ProductPrice: {$push: "$price"}
        }
    }])






















































































































