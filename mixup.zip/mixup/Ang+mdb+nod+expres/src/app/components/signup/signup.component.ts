import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  signupForm: FormGroup; submitted: boolean = false; invalidLogin: boolean = false;
  constructor(private formBuilder: FormBuilder,
    private router: Router, private userservice: UserService) { } l̥
  onSubmit() {
    this.submitted = true;
    if (this.signupForm.invalid) {
      return;
    }
    this.userservice.signupUser(this.signupForm.value)
    console.log(this.signupForm.value)
  }
  ngOnInit() {
    this.signupForm = this.formBuilder.group({
      id: [],
      firstName:['', Validators.required],
      lastName:['', Validators.required],
      email: ['', Validators.required],
      password: ['', Validators.required]
    });
  }
}


