import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { User } from "../model/User";
import { User2 } from '../model/user2';

@Injectable({
  providedIn: "root"
})
export class UserService {
  baseurl: string = "http://localhost:3000/users";
  constructor(private http: HttpClient) {}
  //Modify User
  UpdateUser(user: User) {
    return this.http.put(this.baseurl + "/" + user.id, user);
  }
  getusers() {
    return this.http.get<User[]>(this.baseurl);
  }
  //get Users By Id
  getUsersById(id: number) {
    return this.http.get<User>(this.baseurl + "/" + id);
  }
  deleteUser(id: number) {
    return this.http.delete(this.baseurl + "/" + id);
  }
  addUser(user: User) {
    return this.http.post(this.baseurl, user);
  }
signupUser(user: User2){
  console.log("insignup User")
  return this.http.post(this.baseurl, user);
}
getuser2() {
  
  return this.http.get<User2[]>(this.baseurl);
}
}
