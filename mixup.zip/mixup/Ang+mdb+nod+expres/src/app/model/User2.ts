export class User2 {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    password?: string
}