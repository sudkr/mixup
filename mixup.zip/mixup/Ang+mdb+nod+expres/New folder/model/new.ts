export class New {
    firstname:string;
    lastname:string;
    email:string;
    password:string;
}
