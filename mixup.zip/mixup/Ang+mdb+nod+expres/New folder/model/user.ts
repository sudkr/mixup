export class Task{
    id:number;
    task: string;
    date: string;
    status: string;
    action:string;
}